const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

const Account = require('../models/Account')

const { SECRET_KEY_JWT } = process.env

class AuthServices {
	async userLogin(mail, password) {
		const account = await Account.findOne({ email: mail })
		if (!account) {
			return {
				code: 500,
				message: "Email không tồn tại"
			}
		}

		const isMatch = await bcrypt.compare(password, account.password)

		if (!isMatch) {
			return {
				code: 3,
				message: "Đăng nhập thất bại, mật khẩu không chính xác"
			}
		}

		const { email } = account		
		return { email }
	}

	async userSignup(email,  password) {
		try {
			const hashedPassword = await bcrypt.hash(password, 10);
			console.log(
				email,
				hashedPassword)
			const account = new Account({
			  email,
			  password: hashedPassword
			});
			await account.save();
			console.log('account created');
		  } catch (error) {
			console.log(error.message);
		}
        
	}
}

module.exports = new AuthServices()
