const mongoose = require('mongoose')

const OrderSchema = mongoose.Schema({
	total: {
		type: Number,
		required: true,
	},
    products: [{
        type:  mongoose.Schema.Types.ObjectId,
        ref: 'Product'
    }]
})
const Order = mongoose.model('Order', OrderSchema)
module.exports = Order
