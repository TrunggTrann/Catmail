const Order = require('../models/Order')

class OrdersController {
    async index(req, res) {
        try {
            const orders = await Order.find().populate('products');
            res.json(orders);
          } catch (err) {
            res.status(500).json({ message: err.message });
        }
    }
    async show(req, res) {
        try {
            const order = await Order.findById(req.params.id).populate('products');
            if (order == null) {
              return res.status(404).json({ message: 'Cannot find order' });
            }
            res.json(order);

          } catch (err) {
            return res.status(500).json({ message: err.message });
        }
    }
    async create(req, res) {
        const order = new Order({
            total: req.body.total,
            products: req.body.products
        });
    
        try {
            const newOrder = await order.save();
            res.status(201).json(newOrder);
        } catch (err) {
            res.status(400).json({ message: err.message });
        }
    }
    async update(res, req) {
        let total, products
        if (req.body.total != null) {
            total = req.body.total;
        }
    
        if (req.body.products != null) {
            products = req.body.products;
        }
        const dataUpdate = { total, products }
        try {
            const updatedOrder = await Order.findByIdAndUpdate(req.params.id, dataUpdate, { new: true })
            res.json(updatedOrder);
        } catch (err) {
            res.status(400).json({ message: err.message });
        }
    }
    async destroy(req, res) {
        try {
            const order = await Order.findById(req.params.id);
            if (order == null) {
              return res.status(404).json({ message: 'Cannot find order' });
            }
            await order.remove();
            res.json({ message: 'Order has been deleted' });
          } catch (err) {
            return res.status(500).json({ message: err.message });
        }
        
    }   
	
}

module.exports = new OrdersController()

