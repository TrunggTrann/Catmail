const Product = require('../models/Product')
const multer = require('multer');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'public/images');
    },
    filename: (req, file, cb) => {
      cb(null, `${Date.now()}-${file.originalname}`);
    },
});

const upload = multer({ storage: storage });

class ProductController {
    async index(req, res) {
        try {
            const products = await Product.find()
            res,json(products)
        } catch (err) {
            res.status(500).json({ message: err.message })
        }
    }
    async create(req, res) {
        try {
            const { name, price, description } = req.body;
            const product = new Product({
                name,
                price,
                description,
                image: `images/${req.file.filename}`,
            });
            await product.save();
            res.status(201).json(product);
        } catch (err) {
            res.status(400).json({message: err.message});
        }
    }
    async show(req, res) {
        try {
            const product = await Product.findById(req.params.id);
            if (!product) {
                return res.status(404).json({ message: 'Product not found' });
            }
            res.json(product);
        } catch (err) {
            res.status(500).json({ message: err.message });
        }
    }
    async update(res, req) {
        try {
            const product = await Product.findById(req.params.id);
            if (!product) {
                return res.status(404).json({ message: 'Product not found' });
            }
            product.name = req.body.name;
            product.price = req.body.price;
            product.description = req.body.description;
            if (req.file) {
                product.image = `images/${req.file.filename}`;
            }
            await product.save();
            res.json(product);
        } catch (err) {
            res.status(400).json({ message: err.message });
        }
            
    }
    async destroy(req, res) {
        try {
            const product = await Product.findByIdAndDelete(req.params.id);
            if (!product) {
                return res.status(404).json({ message: 'Product not found' });
            }
            res.json({ message: 'Product deleted' });
        } catch (err) {
            res.status(500).json({ message: err.message });
        }
    }   
	
}

module.exports = new ProductController()

