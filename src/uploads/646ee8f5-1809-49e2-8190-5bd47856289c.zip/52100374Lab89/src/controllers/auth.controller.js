const AuthServices = require('../services/auth.services')
const isValidPayload= require('../payloadValidator/isPayLoadValidator')
const jwt = require("jsonwebtoken")
class AuthContainer {

	async userLogin(req, res) {

		//check payload
		const isValid = await isValidPayload(req)
		if (isValid !== true) {
			return res.status(200).json('Success')
		}

		const { email, password } = req.body

		const result = await AuthServices.userLogin(email, password)
		if (typeof result === 'string') {
			return res.status(200).json('Error')
		}
		const { JWT_SECRET } = process.env
		jwt.sign({ email: result.email }, JWT_SECRET, { expiresIn: '1h'},
			(err, token) => {
				if (err) throw err
				return res.json({
					code: 0,
					message: 'Đăng nhập thành công',
					token: token
				})

			}
		)
	}

	async userSignup(req, res) {
		//check payload
		const isValid = await isValidPayload(req)
		if (isValid !== true) {
			return res.status(200).json('Error')
		}

		const { email, password } = req.body
		const result = await AuthServices.userSignup(email, password)

		if (typeof result === 'string') {
			return res.status(200).json('Error')
		}
		return res.json({
			code: 0,
			message: 'Tạo tài khoản thành công',
			token: token
		})

	}
}

module.exports = new AuthContainer()

