const requireLogin = (req, res, next) => {
    if(req.session && req.session.user) {
        next()
    }
    res.json({ message: "Bạn phải đăng nhập mới vào được đường dẫn này"})
} 
module.exports = requireLogin