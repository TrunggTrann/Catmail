const express = require('express')

const Router = express.Router()
const OrdersController = require('../controllers/orders.controller')
const reuireLogin = require("../util/requireLogin")

Router.put('/:id',  reuireLogin, OrdersController.update)
Router.delete('/:id',  reuireLogin, OrdersController.destroy)
Router.post('/',  reuireLogin, OrdersController.create)

Router.get('/:id', OrdersController.show)
Router.get('/', OrdersController.index)


module.exports = Router 
