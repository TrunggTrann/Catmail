const express = require('express')

const Router = express.Router()
const ProductController = require('../controllers/product.controller')
const reuireLogin = require("../util/requireLogin")


Router.put('/:id',  reuireLogin, ProductController.update)
Router.delete('/:id',  reuireLogin, ProductController.destroy)
Router.post('/',  reuireLogin, ProductController.create)

Router.get('/:id', ProductController.show)
Router.get('/', ProductController.index)


module.exports = Router 
