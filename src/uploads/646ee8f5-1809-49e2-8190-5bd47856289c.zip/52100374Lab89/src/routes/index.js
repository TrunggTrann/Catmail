const authRoute = require('./auth.route')
const productRoute = require('./product.route')
const ordersRoute = require('./orders.route')


const setRoutes = (app) => {


	app.use('/api/account/', authRoute)
	app.use('/api/product', productRoute)
	app.use('/api/orders', ordersRoute)

	

	
	app.get((req, res) => {
		res.send("404 - Error")
	})

	app.use((err, req, res, next) => {
		res.send(err.message)
	})
}
module.exports = setRoutes